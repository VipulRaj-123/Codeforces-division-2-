/*A. Replacing Elements
time limit per test2 seconds
memory limit per test256 megabytes
inputstandard input
outputstandard output
You have an array a1,a2,�,an. All ai are positive integers.

In one step you can choose three distinct indices i, j, and k (i?j; i?k; j?k) and assign the sum of aj and ak to ai, i. e. make ai=aj+ak.

Can you make all ai lower or equal to d using the operation above any number of times (possibly, zero)?

Input
The first line contains a single integer t (1=t=2000) � the number of test cases.

The first line of each test case contains two integers n and d (3=n=100; 1=d=100) � the number of elements in the array a and the value d.

The second line contains n integers a1,a2,�,an (1=ai=100) � the array a.

Output
For each test case, print YES, if it's possible to make all elements ai less or equal than d using the operation above. Otherwise, print NO.

You may print each letter in any case (for example, YES, Yes, yes, yEs will all be recognized as positive answer).

Example
inputCopy
3
5 3
2 3 2 5 4
3 4
2 4 4
5 4
2 1 5 3 6
outputCopy
NO
YES
YES  */

#include <bits/stdc++.h>
using namespace std;

int main() {
	// your code goes here
    int t,n,d;
    cin>>t;
    while(t--)
      {
      cin>>n>>d;
      int a[n];
      for(int i=0;i<n;i++)
        cin>>a[i];
 sort(a,a+n);
 if(a[n-1]<=d||(a[0]+a[1]<=d))
 cout<<"YES"<<endl;
 else
 cout<<"NO"<<endl;
}
	return 0;
}
